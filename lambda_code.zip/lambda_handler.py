import boto3
import time

ec2 = boto3.client('ec2')
lambda_client = boto3.client('lambda')

def create_instance():
    response = ec2.run_instances(
            ImageId='ami-002acc74c401fa86b',
            InstanceType='t2.micro',
            MinCount=1,
            MaxCount=1,
            KeyName='lamb_code_template.pem',
            SecurityGroupIds=['sg-0c0c7e97e9408d824']
    )
    instance_id = response['Instances'][0]['InstanceId']
    return instance_id

def terminate_instance(instance_id):
    ec2.terminate_instances(InstanceIds=[Instance_id])

def my_lambda_handler(event, context):
    Instance_id = create_instance()
    print(f'Created instance {Instance_id}')

    # Schedule termination after 10 minutes
    lambda_client.invoke(
            FunctionName=context.function_name,
            InvocationType='Event',
            Payload=f'{{"instance_id": "{instance_id}"}}'
    )

    return {
       'statusCode': 200,
       'body': f'Instance {instance_id} created and will be terminated in 10 minutes.'
    }

def terminate_handler(event, context):
    instance_id = event['instance_id']
    time.sleep(10 * 60) # Sleep for 10 minutes
    terminate_instance(instance_id)
    print(f'Terminated instance {instance_id}')
